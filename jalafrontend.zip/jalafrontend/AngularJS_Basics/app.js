var app = angular.module("myApp", []);

app.controller("MyController", function($scope) {
    $scope.message = "Welcome to AngularJS";
});

app.directive("myDirective", function() {
    return {
        template: "<h3>This is a Custom Directive</h3>"
    };
});